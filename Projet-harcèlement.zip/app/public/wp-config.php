<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '*e (/B[e[)??qd&kV={fs[QZbKEDL+;LQ7m7gGEYR0/-b$:-tjtTjz7$C`1c2v%z' );
define( 'SECURE_AUTH_KEY',   '(3urj8wiUtBD9ImIViB 2SF8n 56|:Dlm>huV<U5#8_DV/[7t`XgXL6HVdp7}4EH' );
define( 'LOGGED_IN_KEY',     'i3p`jn>xBv]0*/I|$?FaVd2V> 8!DqBDjb =r#fey=ju)7&SH9W-^jn#&>h8KncF' );
define( 'NONCE_KEY',         ' #OWsKL@=S}-|&RIMWy21IE.6)o>zc?^zU%MJ$E/{aX?{EJw4G>8iNl_lKM<Cey(' );
define( 'AUTH_SALT',         '#.Y(l5ntYY4{:-Q~vWSp+*7f6)gz7S/)iq+}v.p!VJp0!_x}byW%HMhBL-x&7_[;' );
define( 'SECURE_AUTH_SALT',  '1XjVwrEEmt[_eZ<SXA3lfboh%<K?1KG7ZFo/09oAb7+pp6j20#q1^(y{zt$Q0GEE' );
define( 'LOGGED_IN_SALT',    'wlcnY<fv@PMe@c*lWl*)~Ke%>I|$MXw:$8`%W@Js]VG~fCBDhL0=.}&GhinvYbu}' );
define( 'NONCE_SALT',        'hW0T#72AW*&m~fUd`:C3p_?0gWH~Cl/ XH^dO3Eb=k)@R#/)B8,L5b`IvIqh5*jL' );
define( 'WP_CACHE_KEY_SALT', 'UIfDzmB!@#a[o9?C];<jPkEwMH+D6.rF(Z7<6PT UwUwI?^!VM]MH8+lg:YK,`M{' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
